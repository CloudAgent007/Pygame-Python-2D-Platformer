import pygame
from pygame.locals import *
import time
#initializing pygame
pygame.init()

#displaying the window
screen_width = 800
screen_height = 800
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('platformer')
#intitializing assets to use in main menu
#the image in the background of the level select screen
level_select_background_before_resize = pygame.image.load('level_select_background.png')
level_select_background = pygame.transform.scale(level_select_background_before_resize, (800, 800))
level_select_background_pos = (0, 0)

#press any button to start button img
press_any_button_to_start_img_before_ressize = pygame.image.load('press_any_button_to_start.png')
press_any_button_to_start_img = pygame.transform.scale(press_any_button_to_start_img_before_ressize, (800, 800))
press_any_button_to_start_img_img_pos = (0, 0)

#buttons in level
#level 1 button img and rect
level_1_button_img_before_resize = pygame.image.load('level_1_button.png')
level_1_button_img = pygame.transform.scale(level_1_button_img_before_resize, (100, 50))
level_1_button_img_pos = (180, 480)
level_1_button_img_rect = Rect(level_1_button_img_pos[0], level_1_button_img_pos[1], level_1_button_img.get_width(), level_1_button_img.get_height())
#level 1 button img pressed
level_1_button_img_hovered_before_resize = pygame.image.load('level_1_button_pressed.png')
level_1_button_img_hovered = pygame.transform.scale(level_1_button_img_hovered_before_resize, (100, 50))

#level 2 button img and rect
level_2_button_img_before_resize = pygame.image.load('level_2_button.png')
level_2_button_img = pygame.transform.scale(level_2_button_img_before_resize, (100, 50))
level_2_button_img_pos = (380, 290)
level_2_button_img_rect = Rect(level_2_button_img_pos[0], level_2_button_img_pos[1], level_2_button_img.get_width(), level_2_button_img.get_height())
#level 2 button img pressed
level_2_button_img_hovered_before_resize = pygame.image.load('level_2_button_pressed.png')
level_2_button_img_hovered = pygame.transform.scale(level_2_button_img_hovered_before_resize, (100, 50))
#locked button 2
level_2_button_locked_img_before_resize = pygame.image.load('level_2_button_locked.png')
level_2_button_locked_img = pygame.transform.scale(level_2_button_locked_img_before_resize, (100, 50))

#level 3 button img and rect
level_3_button_img_before_resize = pygame.image.load('level_3_button.png')
level_3_button_img = pygame.transform.scale(level_3_button_img_before_resize, (100, 50))
level_3_button_img_pos = (650, 430)
level_3_button_img_rect = Rect(level_3_button_img_pos[0], level_3_button_img_pos[1], level_3_button_img.get_width(), level_3_button_img.get_height())
#level 3 button img pressed
level_3_button_img_hovered_before_resize = pygame.image.load('level_3_button_pressed.png')
level_3_button_img_hovered = pygame.transform.scale(level_3_button_img_hovered_before_resize, (100, 50))
#locked button 2
level_3_button_locked_img_before_resize = pygame.image.load('level_3_button_locked.png')
level_3_button_locked_img = pygame.transform.scale(level_3_button_locked_img_before_resize, (100, 50))

#level background image plain
level_background_image_before_resize = pygame.image.load('level_background_img.png')
level_background_image = pygame.transform.scale(level_background_image_before_resize, (150, 175))

#level background image dark
level_background_image_dark_before_resize = pygame.image.load('locked_level_background_img.png')
level_background_image_dark = pygame.transform.scale(level_background_image_dark_before_resize, (150, 175))

#level background image for when game complete
game_tab_background_before_resize = pygame.image.load('level_background_img.png')
game_tab_background = pygame.transform.scale(game_tab_background_before_resize, (300, 150))
game_tab_background_pos = (275, 50)

#leave button img
leave_button_img_before_resize = pygame.image.load('leave_button.png')
leave_button_img = pygame.transform.scale(leave_button_img_before_resize, (200, 100))
leave_button_img_pos = (550, 650)
leave_button_rect = Rect(leave_button_img_pos[0], leave_button_img_pos[1], leave_button_img.get_width(), leave_button_img.get_height())
#leave button hovered img
leave_button_hovered_img_before_resize = pygame.image.load('leave_button_hover.png')
leave_button_hovered_img = pygame.transform.scale(leave_button_hovered_img_before_resize, (200, 100))

#reset progress button
#reset progress img
reset_progress_button_img_before_resize = pygame.image.load('reset_progress_button.png')
reset_progress_button_img = pygame.transform.scale(reset_progress_button_img_before_resize, (200, 100))
reset_progress_button_img_pos = (50, 650)
#reset progress img hovered
reset_progress_button_hovered_img_before_resize = pygame.image.load('reset_progress_hovered_button.png')
reset_progress_button_hovered = pygame.transform.scale(reset_progress_button_hovered_img_before_resize, (200, 100))
reset_button_rect = Rect(reset_progress_button_img_pos[0], reset_progress_button_img_pos[1],reset_progress_button_img.get_width(), reset_progress_button_img.get_height())

#text_font
game_complete_text_font = pygame.font.SysFont("Arial", 36, True)
text_font = pygame.font.SysFont("Arial", 26, True)
mini_text_font = pygame.font.SysFont("Arial", 14, True)

#function to draw any text onto the screen
def drawing_text(text, font, text_col, x, y):
    img = font.render(text, True , text_col)
    screen.blit(img, (x, y))
#reading the data
def reading_DATA():
    #reading file and storing variables required for when rewritting the text file
    file = open('DATA.txt', 'r')
    incomplete_line = file.readline()
    complete_line = file.readline()
    level_1 = file.readline()
    level_2 = file.readline()
    level_3 = file.readline()
    tuple_var = (incomplete_line, complete_line, level_1, level_2, level_3)
    file.close()
    return tuple_var

def rewriting_DATA():
    #reading file and storing variables required for when rewritting the text file
    file = open('DATA.txt', 'r')
    incomplete_line = file.readline()
    complete_line = file.readline()
    file.close()
    #writting on the file
    file = open('DATA.txt', 'w')
    file.writelines(incomplete_line)
    file.writelines(complete_line)
    file.writelines(incomplete_line)
    file.writelines(incomplete_line)
    file.writelines(incomplete_line)
    file.close()

#list of smooth transition images
smooth_transitions_imgs = []
#for loop which adds each image into the list
for i in range(31):
    if i == 0:
        smooth_transitions_imgs.append(f'press_any_button_to_start.png')
    else:
        smooth_transitions_imgs.append(f'pressed_any_button_to_start_{i}.png')

#leave button function which returns true or false depending on whether it's being hovered or not
def leave_button():
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    if mouse_rect.colliderect(leave_button_rect):
        return True
    else:
        return False

#reset button function which returns true or false depending on whether it's being hovered or not
def reset_progress_button():
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    if mouse_rect.colliderect(reset_button_rect):
        return True
    else:
        return False

#button function which returns a tuple with a true or false boolean variable whether the button is being hovered or not
def buttons():
    #making the mouse button into a 1 by 1 rect
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    #checking if the mouse rect is colliding with the level 1 button rect
    if mouse_rect.colliderect(level_1_button_img_rect):
        level_1_button_collided = True
    else:
        level_1_button_collided = False
    #checking if the mouse rect is colliding with the level 2 button rect
    if mouse_rect.colliderect(level_2_button_img_rect):
        level_2_button_collided = True
    else:
        level_2_button_collided = False
    #checking if the mouse rect is colliding with the level 3 button rect
    if mouse_rect.colliderect(level_3_button_img_rect):
        level_3_button_collided = True
    else:
        level_3_button_collided = False
    #returning all 3 variables in a tuple
    tuple_var = (level_1_button_collided, level_2_button_collided, level_3_button_collided)
    return tuple_var

#running function which displays 
def game_complete_tab():
        screen.blit(game_tab_background, (game_tab_background_pos[0], game_tab_background_pos[1]))
        drawing_text('game complete', game_complete_text_font, (148,0,211), 295, 70)
        drawing_text('We saw many wonderfull gods and', mini_text_font, (255,255,255), 295, 110)
        drawing_text('beasts on our journey, Taniwha,', mini_text_font, (255,255,255), 295, 130)
        drawing_text('The goat man, even  Kiho-tumo!', mini_text_font, (255,255,255), 295, 150)
        drawing_text('Well played, you got back home.', mini_text_font, (255,255,255), 295, 170)


def casual_game_tab():
    screen.blit(game_tab_background, (game_tab_background_pos[0], game_tab_background_pos[1]))
    drawing_text('It is reccomended to read the help', mini_text_font, (255,255,255), 295, 100)
    drawing_text('section in each level. Which can be', mini_text_font, (255,255,255), 295, 115)
    drawing_text('found in the pause menu in each level.', mini_text_font, (255,255,255), 295, 130)
#grabbing key presses for later
key_2 = pygame.key.get_pressed()
#clock which determines fps (frames per seccond)
clock = pygame.time.Clock()
#variable for the press any key to start loop
press_any_key_to_start_menu = True
#loop which runs untill a key is pressed
while press_any_key_to_start_menu:
    clock.tick(25)
    key = pygame.key.get_pressed()
    #checking if key is pressed
    if key != key_2:
        press_any_key_to_start_menu = False
    else:
        screen.blit(press_any_button_to_start_img, (press_any_button_to_start_img_img_pos[0], press_any_button_to_start_img_img_pos[1]))
        drawing_text('press any button to start', text_font, (255,255,255), 250, 350)
    #check whether human closes window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
    #updating graphics
    pygame.display.update()

#smooth transition into main game menu
num = 0
while num <= len(smooth_transitions_imgs) - 1:
    #screen blitting the level select img
    screen.blit(level_select_background, (level_select_background_pos[0], level_select_background_pos[1]))
    #grabbing the selected img from the img list and resizing it
    transition_img_before_resize = pygame.image.load(smooth_transitions_imgs[num])
    transition_img = pygame.transform.scale(transition_img_before_resize, (800, 800))
    #displaying transition img
    screen.blit(transition_img, (0, 0))
    num += 1
    #checking if human closses the window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
    #updating graphics
    pygame.display.update()

#first time run variables
first_time_run_level_1 = True
first_time_run_level_2 = True
first_time_run_level_3 = True
#whie loop var
done = False
#while loop
while done == False:
    #running at 20 fps
    clock.tick(20)
    #updating the background
    screen.blit(level_select_background, (level_select_background_pos[0], level_select_background_pos[1]))
    #updating the buttons displayed
    buttons_tuple_var = buttons()
    #reading the data.txt file and returning the status of all 3 levels
    level_data_tuple_var = reading_DATA()
    #if hovering on level 1
    if buttons_tuple_var[0] == True:
        screen.blit(level_background_image,(155, 460))
        screen.blit(level_1_button_img_hovered, (level_1_button_img_pos[0], level_1_button_img_pos[1]))
        drawing_text('Easy', text_font, (0, 255, 0), 200, 570)
        #if the player clicks then run level 1
        if event.type == pygame.MOUSEBUTTONDOWN:
            #running the script differently if its the first time runnings the script
            if first_time_run_level_1 == True:
                #running the level 1 script on the first boot
                import LEVEL_1
                first_time_run_level_1 = False
            else:
                #running the level 1 script
                with open("LEVEL_1.py") as f:
                    exec(f.read())
            #re initializing pygame screen because I need to apparently
            pygame.init()
            screen_width = 800
            screen_height = 800
            screen = pygame.display.set_mode((screen_width, screen_height))
            pygame.display.set_caption('platformer')
    else:
        screen.blit(level_1_button_img, (level_1_button_img_pos[0], level_1_button_img_pos[1]))
    #if hovering on level 2
    if buttons_tuple_var[1] == True and level_data_tuple_var[1] != level_data_tuple_var[2]:
        #display the locked logo if you haven't complete level 1
        screen.blit(level_background_image_dark, (355, 270))
        screen.blit(level_2_button_locked_img, (level_2_button_img_pos[0], level_2_button_img_pos[1]))
        drawing_text('locked', text_font, (255, 255, 255), 390, 380)
    elif buttons_tuple_var[1] == True:
        screen.blit(level_background_image, (355, 270))
        screen.blit(level_2_button_img_hovered, (level_2_button_img_pos[0], level_2_button_img_pos[1]))
        drawing_text('Medium', text_font, (255, 255, 0), 380, 380)
        if event.type == pygame.MOUSEBUTTONDOWN:
            #running the script differently if its the first time runnings the script
            if first_time_run_level_2 == True:
                #running the level 2 script on the first boot
                import LEVEL_2
                first_time_run_level_2 = False
            else:
                #running the level 2 script
                with open("LEVEL_2.py") as f:
                    exec(f.read())
            #re initializing pygame screen because I need to apparently
            pygame.init()
            screen_width = 800
            screen_height = 800
            screen = pygame.display.set_mode((screen_width, screen_height))
            pygame.display.set_caption('platformer')
    else:
        screen.blit(level_2_button_img, (level_2_button_img_pos[0], level_2_button_img_pos[1]))

    #if hovering on level 3
    if buttons_tuple_var[2] == True and level_data_tuple_var[1] != level_data_tuple_var[3]:
        #display the locked logo if you haven't complete level 2
        screen.blit(level_background_image_dark, (625, 410))
        screen.blit(level_3_button_locked_img, (level_3_button_img_pos[0], level_3_button_img_pos[1]))
        drawing_text('locked', text_font, (255, 255, 255), 660, 490)
    elif buttons_tuple_var[2] == True:
        screen.blit(level_background_image, (625, 410))
        screen.blit(level_3_button_img_hovered, (level_3_button_img_pos[0], level_3_button_img_pos[1]))
        drawing_text('Hard', text_font, (255, 0, 0), 670, 490)
        if event.type == pygame.MOUSEBUTTONDOWN:
            #running the script differently if its the first time runnings the script
            if first_time_run_level_3 == True:
                #running the level 2 script on the first boot
                import LEVEL_3
                first_time_run_level_3 = False
            else:
                #running the level 2 script
                with open("LEVEL_3.py") as f:
                    exec(f.read())
            #re initializing pygame screen because I need to apparently
            pygame.init()
            screen_width = 800
            screen_height = 800
            screen = pygame.display.set_mode((screen_width, screen_height))
            pygame.display.set_caption('platformer')
    else:
        screen.blit(level_3_button_img, (level_3_button_img_pos[0], level_3_button_img_pos[1]))
    #leave button function
    if leave_button() == True:
        screen.blit(leave_button_hovered_img, (leave_button_img_pos[0], leave_button_img_pos[1]))
        if event.type == pygame.MOUSEBUTTONDOWN:
            pygame.quit()
    else:
        screen.blit(leave_button_img, (leave_button_img_pos[0], leave_button_img_pos[1]))
    #reset button function
    if reset_progress_button() == True:
        screen.blit(reset_progress_button_hovered, (reset_progress_button_img_pos[0], reset_progress_button_img_pos[1]))
        if event.type == pygame.MOUSEBUTTONDOWN:
            rewriting_DATA()
    else:
        screen.blit(reset_progress_button_img, (reset_progress_button_img_pos[0], reset_progress_button_img_pos[1]))
    
    #function which displays a game complete tab if you finished the game
    if reading_DATA()[1] == reading_DATA()[4]:
        game_complete_tab()
    else:
        casual_game_tab()
    #checking whether the player closses the game
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
    #updating the graphics
    pygame.display.update()
pygame.quit()