#pygame stuff
#imports
import pygame
from pygame.locals import *
import time
#initializing pygame
pygame.init()

#displaying the window
screen_width = 800
screen_height = 800
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('platformer')

#loading images
bg_img = pygame.image.load('sky.png')
#exit door image
exit_door_img_before_resize = pygame.image.load('door_level_exit.png')
exit_door_img = pygame.transform.scale(exit_door_img_before_resize, (50, 100))
exit_door_pos = (750, 500)
exit_door_rect = Rect(exit_door_pos[0], exit_door_pos[1], exit_door_img.get_width(), exit_door_img.get_height())

#game complete background
game_complete_background_img_before_resize = pygame.image.load('game_complete_background.png')
game_complete_background_img = pygame.transform.scale(game_complete_background_img_before_resize, (600, 600))
game_complete_background_pos = (100, 100)

#_menu button image
main_menu_button_image_before_resize = pygame.image.load('main_menu_button.png')
main_menu_image = pygame.transform.scale(main_menu_button_image_before_resize, (70, 35))
main_menu_pos = (700, 50)

#menu button image hovered
main_menu_button_image_hovered_before_resize = pygame.image.load('main_menu_hover.png')
main_menu_image_hovered = pygame.transform.scale(main_menu_button_image_hovered_before_resize, (70, 35))

#quit button image
quit_button_image_before_resize = pygame.image.load('quit_button.png')
quit_button_image = pygame.transform.scale(quit_button_image_before_resize, (200, 100))
quit_button_pos = (150, 350)

#quit button image hovered
quit_button_image_hovered_before_resize = pygame.image.load('quit_button_hover.png')
quit_button_image_hovered = pygame.transform.scale(quit_button_image_hovered_before_resize, (200, 100))

#retry button image
retry_button_image_before_resize = pygame.image.load('retry_button.png')
retry_button_image = pygame.transform.scale(retry_button_image_before_resize, (200, 100))
retry_button_pos = (450, 350)

#retry button image hovered
retry_button_image_hovered_before_resize = pygame.image.load('retry_button_hovered.png')
retry_button_image_hovered = pygame.transform.scale(retry_button_image_hovered_before_resize, (200, 100))

#main menu buttons:
#main menu background img (the image behind the buttons)
main_menu_background_img_before_resize = pygame.image.load('main_menu_background.png')
main_menu_background_img =  pygame.transform.scale(main_menu_background_img_before_resize, (400, 600))
main_menu_background_img_pos = (200, 100)

#resume button
resume_button_img_before_resize = pygame.image.load('resume_button.png')
resume_button_img = pygame.transform.scale(resume_button_img_before_resize, (200, 100))
resume_button_img_pos = (300, 140)
#resume button hovered
resume_button_hovered_img_before_resize = pygame.image.load('resume_button_hover.png')
resume_button_hovered_img = pygame.transform.scale(resume_button_hovered_img_before_resize, (200, 100))

#restart button
restart_button_before_resize = pygame.image.load('restart_button.png')
restart_button_img = pygame.transform.scale(restart_button_before_resize, (200, 100))
restart_button_img_pos = (300, 280)
#restart button hovered
restart_button_hovered_img_before_resize = pygame.image.load('restart_button_hovered.png')
restart_button_hovered_img = pygame.transform.scale(restart_button_hovered_img_before_resize, (200, 100))

#help button
help_button_img_before_resize = pygame.image.load('help_button.png')
help_button_img = pygame.transform.scale(help_button_img_before_resize, (200, 100))
help_button_img_pos = (300, 420)
#help button hovered
help_button_hovered_img_before_resize = pygame.image.load('help_button_hover.png')
help_button_hovered_img = pygame.transform.scale(help_button_hovered_img_before_resize, (200, 100))

#help option: next button img
next_button_img_before_resize = pygame.image.load('help_option_next_button.png')
next_button_img = pygame.transform.scale(next_button_img_before_resize, (70, 70))
next_button_img_pos = (500, 570)
next_button_rect = Rect(next_button_img_pos[0], next_button_img_pos[1], next_button_img.get_width(), next_button_img.get_height())

#help option: next button img hovered
next_button_img_hovered_before_resize = pygame.image.load('help_option_next_button_hovered.png')
next_button_hovered_img = pygame.transform.scale(next_button_img_hovered_before_resize, (70, 70))

#help option: back button img
back_button_img_before_resize = pygame.image.load('help_option_back_button.png')
back_button_img = pygame.transform.scale(back_button_img_before_resize, (70, 70))
back_button_img_pos = (230, 570)
back_button_rect = Rect(back_button_img_pos[0], back_button_img_pos[1], back_button_img.get_width(), back_button_img.get_height())

#help option: back button img hovered
back_button_img_hovered_before_resize =  pygame.image.load('help_option_back_button_hovered.png')
back_button_img_hovered = pygame.transform.scale(back_button_img_hovered_before_resize, (70, 70))

#help option: mini enemy image
mini_enemy_img_before_resize = pygame.image.load('taniwha_left.png')
mini_enemy_img = pygame.transform.scale(mini_enemy_img_before_resize, (50, 25))
mini_enemy_img_pos = (230, 135)

#help option: mini character image
mini_guy_img_before_resize = img = pygame.image.load('guy.png')
mini_guy_img = pygame.transform.scale(mini_guy_img_before_resize, (40, 80))
mini_guy_img_pos = (230, 220)

#help option: reactive buttons
#help option: w button not pressed
w_reactive_img_before_resize = pygame.image.load('w.png')
w_reactive_img = pygame.transform.scale(w_reactive_img_before_resize, (100, 100))
#help option: w button pressed
w_reactive_img_before_resize_hovered = pygame.image.load('w_hovered.png')
w_reactive_img_pressed = pygame.transform.scale(w_reactive_img_before_resize_hovered, (100, 100))

#help option: a button not pressed
a_reactive_img_before_resize = pygame.image.load('a.png')
a_reactive_img = pygame.transform.scale(a_reactive_img_before_resize, (100, 100))
#help option: a button pressed
a_reactive_img_before_resize_hovered = pygame.image.load('a_hovered.png')
a_reactive_img_pressed = pygame.transform.scale(a_reactive_img_before_resize_hovered, (100, 100))

#help option: d button not pressed
d_reactive_img_before_resize = pygame.image.load('d.png')
d_reactive_img = pygame.transform.scale(d_reactive_img_before_resize, (100, 100))
#help option: d button pressed
d_reactive_img_before_resize_hovered = pygame.image.load('d_hovered.png')
d_reactive_img_pressed = pygame.transform.scale(d_reactive_img_before_resize_hovered, (100, 100))

#leave button img
leave_button_img_before_resize = pygame.image.load('leave_button.png')
leave_button_img = pygame.transform.scale(leave_button_img_before_resize, (200, 100))
leave_button_img_pos = (300, 550)
#leave button hovered
leave_button_hovered_img_before_resize = pygame.image.load('leave_button_hover.png')
leave_button_hovered_img = pygame.transform.scale(leave_button_hovered_img_before_resize, (200, 100))

#seperate leave button for when completed the game
leave_button_img_2 = pygame.transform.scale(leave_button_img_before_resize, (400, 200))
leave_button_hovered_img_2 = pygame.transform.scale(leave_button_hovered_img_before_resize, (400, 200))
leave_button_img_2_pos = (200, 400)
leave_button_img_2_rect = Rect(leave_button_img_2_pos[0], leave_button_img_2_pos[1], leave_button_img_2.get_width(), leave_button_img_2.get_height())
#text font for writting in game
text_font = pygame.font.SysFont("Arial", 26, True)
#game variables
#level data variables
tile_size = 40
rows = 20
columns = 20
row_size = 0
column_size = 0
#other variables
num = 0
death = False
game_paused = False
offer_retry = False
game_complete = False
help_option_selected = False
help_option_next_page_selected = False
#walking animation right
#animation right
walking_right = ['guy-right-1.png','guy-right-1.png','guy-right-1.png','guy-right-1.png','guy-right-1.png', 'guy-right-2.png','guy-right-2.png','guy-right-2.png','guy-right-2.png','guy-right-2.png', 'guy-right-1.png','guy-right-1.png','guy-right-1.png','guy-right-1.png','guy-right-1.png', 'guy-right-3.png','guy-right-3.png','guy-right-3.png','guy-right-3.png','guy-right-3.png']
#animation left
walking_left = ['guy-left-1.png', 'guy-left-1.png', 'guy-left-1.png', 'guy-left-1.png', 'guy-left-1.png', 'guy-left-2.png', 'guy-left-2.png', 'guy-left-2.png', 'guy-left-2.png', 'guy-left-2.png', 'guy-left-1.png', 'guy-left-1.png','guy-left-1.png','guy-left-1.png','guy-left-1.png','guy-left-3.png','guy-left-3.png','guy-left-3.png','guy-left-3.png','guy-left-3.png']
#enemy animaions
#enemy left walking animation
enemy_walking_left = pygame.image.load('taniwha_left.png')
#enemy right walking animation
enemy_walking_right = pygame.image.load('taniwha_right.png')
#enemy dying animation list
enemy_dying_list = ['taniwha_dying_1.png', 'taniwha_dying_1.png','taniwha_dying_2.png','taniwha_dying_2.png','taniwha_dying_3.png','taniwha_dying_3.png','taniwha_dying_4.png','taniwha_dying_4.png','taniwha_dying_5.png','taniwha_dying_5.png','taniwha_dying_6.png','taniwha_dying_6.png','taniwha_dying_7.png','taniwha_dying_7.png','taniwha_dying_8.png','taniwha_dying_8.png','taniwha_dying_9.png','taniwha_dying_9.png','taniwha_dying_10.png','taniwha_dying_10.png','taniwha_dying_11.png','taniwha_dying_11.png','taniwha_dying_12.png','taniwha_dying_12.png',]
#lists that contain cordintes for blipping
places_to_blip_dirt = []
dirt_collider_list = []
places_to_blip_grass = []
grass_collider_list = []
places_to_blip_lava = []
lava_collider_list = []
places_to_blip_floor_spike = []
floor_spike_collider_list = []
places_to_blip_roof_spike = []
roof_spike_collider_list = []

#loading images for levea data
#dirt png
dirt_img = pygame.image.load('dirt.png')
#grass png
grass_img = pygame.image.load('grass.png')
#lava png
lava_img = pygame.image.load('lava.png')
#floor spike
floor_spike_img = pygame.image.load('floor_spike.png')
#roof spike
roof_spike_img = pygame.image.load('roof_spike.png')

#help option selected images - used in the help menu
help_option_dirt_img = pygame.transform.scale(dirt_img, (tile_size, tile_size))
help_option_grass_img = pygame.transform.scale(grass_img, (tile_size, tile_size))
help_option_lava_img = pygame.transform.scale(lava_img, (tile_size, tile_size))
help_option_floor_spike_img = pygame.transform.scale(floor_spike_img, (tile_size, tile_size / 2))
help_option_roof_spike_img = pygame.transform.scale(roof_spike_img, (tile_size, tile_size / 2))
help_option_exit_door_img = pygame.transform.scale(exit_door_img_before_resize, (tile_size, tile_size * 2))
#text font for help option menu
help_option_text_font = pygame.font.SysFont("Arial", 15)
#the level data
level_data = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 2, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 2, 0, 0, 0, 5, 5, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    5, 5, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 2, 2, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 2, 2,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 3, 3, 3, 1, 1,
]

#variable for linear searching through the world data list
Linear_search = 0
#for loop for colums
for i in range(columns):
    #for loop for rows
    for i in range(rows):
        #displaying dirt code
        if level_data[Linear_search] == 1:
           #transforming image size to tile size (tilze size is 80 pizels)
           dirt_img_resized = pygame.transform.scale(dirt_img, (tile_size, tile_size))
           #adding the cordinates of the item found in world data to a list.
           places_to_blip_dirt.append(column_size)
           places_to_blip_dirt.append(row_size)
           #adding dirt colider items to list
           dirt_rect = Rect(column_size, row_size, tile_size, tile_size)
           dirt_rect.x = row_size
           dirt_rect.y = column_size
           dirt_collider_list.append(dirt_rect)
        #displaying grass code
        elif level_data[Linear_search] == 2:
           #transforming image size to tile size (tilze size is 40 pixels)
           grass_img_resized = pygame.transform.scale(grass_img, (tile_size, tile_size))
           #adding the cordinates of the item found in world data to a list.
           places_to_blip_grass.append(column_size)
           places_to_blip_grass.append(row_size)
            #adding grass colider items to rect list
           grass_rect = Rect(column_size, row_size, tile_size, tile_size)
           grass_rect.x = row_size
           grass_rect.y = column_size
           grass_collider_list.append(grass_rect)
        #displaying lava code
        elif level_data[Linear_search] == 3:
            lava_img_resized = pygame.transform.scale(lava_img, (tile_size, tile_size))
            places_to_blip_lava.append(column_size)
            places_to_blip_lava.append(row_size)
            #adding grass colider items to rect list
            lava_rect =  Rect(column_size, row_size, tile_size, tile_size)
            lava_rect.x = row_size
            lava_rect.y = column_size
            lava_collider_list.append(lava_rect)
        #display floor spike
        elif level_data[Linear_search] == 4:
            floor_spike_img_resized = pygame.transform.scale(floor_spike_img, (tile_size, tile_size / 2))
            places_to_blip_floor_spike.append(column_size + (tile_size / 2))
            places_to_blip_floor_spike.append(row_size)
            #adding floor spike items to list
            floor_spike_rect = Rect(column_size + (tile_size / 2), row_size, tile_size, tile_size / 2)
            floor_spike_rect.x = row_size
            floor_spike_rect.y = column_size + (tile_size / 2)
            floor_spike_collider_list.append(floor_spike_rect)
        #display roof spike
        elif level_data[Linear_search] == 5:
            roof_spike_img_resized = pygame.transform.scale(roof_spike_img, (tile_size, tile_size / 2))
            places_to_blip_roof_spike.append(column_size)
            places_to_blip_roof_spike.append(row_size)
            #adding roof spike items to list
            roof_spike_rect = Rect(column_size, row_size, tile_size, tile_size / 2)
            roof_spike_rect.x = row_size
            roof_spike_rect.y = column_size
            roof_spike_collider_list.append(roof_spike_rect)
        #checking the next list item
        Linear_search += 1
        #going to the next list item cordinates for rows and columns
        row_size += tile_size
    column_size += tile_size
    #cordinate stuff - row goes back to zero at the start of each column
    row_size = 0

#function to display the blocks the level data by checking the list item cordinates and blipping them into existance
def updating_world_data_displayed(for_loop_dirt_var, for_loop_grass_var, for_loop_lava_var, for_loop_floor_spike_var, for_loop_roof_spike_var):
    #display dirt
    #position in the list
    dirt_list_pos = 0
    for i in range(for_loop_dirt_var):
        #adding item onto screen
        screen.blit(dirt_img_resized, (places_to_blip_dirt[dirt_list_pos + 1], places_to_blip_dirt[dirt_list_pos]))
        #moving two spaces forward in the list because the cordinates take up two list spaces
        dirt_list_pos += 2
    #display grass
    #position in the list
    grass_list_pos = 0
    for i in range(for_loop_grass_var):
        #adding item onto screen
        screen.blit(grass_img_resized, (places_to_blip_grass[grass_list_pos + 1], places_to_blip_grass[grass_list_pos]))
        #moving two spaces forward in the list because the cordinates take up two list spaces
        grass_list_pos += 2
    #display lava
    #position in list
    lava_list_pos = 0
    for i in range(for_loop_lava_var):
        #adding item to screen
        screen.blit(lava_img_resized, (places_to_blip_lava[lava_list_pos + 1], places_to_blip_lava[lava_list_pos]))
        #moving two spaces forward in the list because the cordinates take up two list spaces
        lava_list_pos += 2
    #display floor spike
    #position in list
    floor_spike_list_pos = 0
    for i in range(for_loop_floor_spike_var):
        #adding item to screen
        screen.blit(floor_spike_img_resized, (places_to_blip_floor_spike[floor_spike_list_pos + 1], places_to_blip_floor_spike[floor_spike_list_pos]))
        #moving two spaces forward in the list because the cordinates take up two list spaces
        floor_spike_list_pos += 2
    #display floor spike
    #position in list  
    roof_spike_list_pos = 0
    for i in range(for_loop_roof_spike_var):
        #adding item to screen
        screen.blit(roof_spike_img_resized, (places_to_blip_roof_spike[roof_spike_list_pos + 1], places_to_blip_roof_spike[roof_spike_list_pos]))
        #moving two spaces forward in the list because the cordinates take up two list spaces
        roof_spike_list_pos += 2
#the reason we only want our for loop to run half the amount of times of our list items, is because we are checking for two list items each time.
for_loop_dirt_var = int(len(places_to_blip_dirt) / 2)
for_loop_grass_var = int(len(places_to_blip_grass) / 2)
for_loop_lava_var = int(len(places_to_blip_lava) / 2)
for_loop_floor_spike_var = int(len(places_to_blip_floor_spike) / 2)
for_loop_roof_spike_var = int(len(places_to_blip_roof_spike) / 2)
#creating enemy class
class enemy():
    def __init__(enemy_self, x, y):
        img = pygame.image.load('taniwha_left.png')
        enemy_self.image = pygame.transform.scale(img, (60, 30))
        enemy_self.rect = enemy_self.image.get_rect()
        enemy_self.rect.x = x
        enemy_self.rect.y = y
        enemy_self.width = enemy_self.image.get_width()
        enemy_self.height = enemy_self.image.get_height()
        enemy_self.vel_y = 0
        enemy_self.image_select = 0
        enemy_self.moving_left = True
    #updating enemy
    def update(enemy_self):
        def switch_direction():
            if enemy_self.moving_left == True:
                enemy_self.moving_left = False
                enemy_self.image_select = 0
            else:
                enemy_self.moving_left = True
                enemy_self.image_select = 0
        #directional x and y variables
        dx = 0
        dy = 0
        #if enemy is moving left then use left animations and move enemy to the left
        if enemy_self.moving_left == True and enemy_self.image_select != 30:
            img =  enemy_walking_left
            enemy_self.image = pygame.transform.scale(img, (60, 30))
            enemy_self.image_select += 1
            dx -= 4
        #if enemy is moving right then use right animations and move enemy to the right
        elif enemy_self.moving_left == False and enemy_self.image_select != 30:
            img =  enemy_walking_right
            enemy_self.image = pygame.transform.scale(img, (60, 30))
            enemy_self.image_select += 1
            dx += 4
        if enemy_self.moving_left == True and enemy_self.image_select == 30:
            switch_direction()
        if enemy_self.moving_left == False and enemy_self.image_select == 30:
            switch_direction()
        #DIRT COLLISION
        #check for collision in x direction
        for dirt_block in range(len(dirt_collider_list)):
            dirt_rect = dirt_collider_list[dirt_block]
            if dirt_rect.colliderect(enemy_self.rect.x + dx, enemy_self.rect.y, enemy_self.width, enemy_self.height):
                dx = 0
                switch_direction()
		    #check for collision in y direction
            if dirt_rect.colliderect(enemy_self.rect.x, enemy_self.rect.y + dy, enemy_self.width, enemy_self.height):
		    #check if colliding from below
                if enemy_self.vel_y < 0:
                    dy = -1
                    enemy_self.vel_y = 0
		    	#check if colliding from above
                elif enemy_self.vel_y >= 0:
                    dy = dirt_rect.top - enemy_self.rect.bottom
                    enemy_self.vel_y = 0
        #GRASS COLLISION
        #check for collision in x direction
        for grass_block in range(len(grass_collider_list)):
            grass_rect = grass_collider_list[grass_block]
            if grass_rect.colliderect(enemy_self.rect.x + dx, enemy_self.rect.y, enemy_self.width, enemy_self.height):
                dx = 0
                switch_direction()
		    #check for collision in y direction
            if grass_rect.colliderect(enemy_self.rect.x, enemy_self.rect.y + dy, enemy_self.width, enemy_self.height):
		    #check if colliding from below
                if enemy_self.vel_y < 0:
                    dy = -1
                    enemy_self.vel_y = 0
		    	#check if colliding from above
                elif enemy_self.vel_y >= 0:
                    dy = 0
                    enemy_self.vel_y = 0
        #check for lava collision
        for lava_block in range(len(lava_collider_list)):
            lava_rect = lava_collider_list[lava_block]
            if lava_rect.colliderect(enemy_self.rect.x + dx, enemy_self.rect.y, enemy_self.width, enemy_self.height):
                dx = 0
                switch_direction()
        #check for floor spike collision
        for floor_spike in range(len(floor_spike_collider_list)):
            floor_spike_rect = floor_spike_collider_list[floor_spike]
            if floor_spike_rect.colliderect(enemy_self.rect.x + dx, enemy_self.rect.y, enemy_self.width, enemy_self.height):
                dx = 0
                switch_direction()
        #check for roof spike collision
        for roof_spike in range(len(roof_spike_collider_list)):
            roof_spike_rect = roof_spike_collider_list[roof_spike]
            if roof_spike_rect.colliderect(enemy_self.rect.x + dx, enemy_self.rect.y, enemy_self.width, enemy_self.height):
                dx = 0
                switch_direction()
        #updating enemy_self.rect
        #update player coorditnates
        enemy_self.rect.x += dx
        enemy_self.rect.y += dy
        #adding boundries to bottom
        if enemy_self.rect.bottom > screen_height:
            enemy_self.rect.bottom = screen_height
            dy = 0
        #adding horizontal boundaries
        if enemy_self.rect.right > screen_width:
            enemy_self.rect.x = screen_width - enemy_self.width
            switch_direction()
        elif enemy_self.rect.left < 0:
            enemy_self.rect.x = 0
            switch_direction()
        #adding enemy to screen
        screen.blit(enemy_self.image, enemy_self.rect)
        #returning the self rect and self image
        tuple_var_for_enemy = (enemy_self.rect, enemy_self.image)
        return tuple_var_for_enemy
    #enemy death function
    def enemy_dying_animation(enemy_self, death_animation_var):
        img = pygame.image.load(enemy_dying_list[death_animation_var])
        enemy_self.image = pygame.transform.scale(img, (60, 30))
        screen.blit(enemy_self.image, enemy_self.rect)
#creating a character class
class Player():
    def __init__(self, x, y):
        self.right = False
        self.left = False
        img = pygame.image.load('guy.png')
        self.image = pygame.transform.scale(img, (30, 60))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.vel_y = 0
        self.jumped = False
        self.image_select = 0
        self.killed_enemy = False
        #updating person
    def update(self, enemy_rect, enemy_killed):
        death = False
        self.right = False
        self.left = False
        dx = 0
        dy = 0
        #get keypresses
        key = pygame.key.get_pressed()
        if key[pygame.K_w] and self.jumped == False or key[pygame.K_UP] and self.jumped == False:
            self.vel_y = -13
            self.jumped = True
        if key[pygame.K_a] or key[pygame.K_LEFT]:
            dx -= 5
            self.left = True
        if key[pygame.K_d] or key[pygame.K_RIGHT]:
            dx += 5
            self.right = True
        #add gravity
        self.vel_y += 1
        if self.vel_y > 10:
            self.vel_y = 10
        dy += self.vel_y

        #stopping people from jumping over and over part 1
        if dy == 0 and self.jumped == True:
            self.jumped = False
        else:
            self.jumped = True

        #DIRT COLLISION
        #check for collision in x direction
        for dirt_block in range(len(dirt_collider_list)):
            dirt_rect = dirt_collider_list[dirt_block]
            if dirt_rect.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0
		    #check for collision in y direction
            if dirt_rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
		    #check if colliding from below
                if self.vel_y < 0:
                    dy = -1
                    self.vel_y = 0
		    	#check if colliding from above
                elif self.vel_y >= 0:
                    dy = dirt_rect.top - self.rect.bottom
                    self.vel_y = 0
        #GRASS COLLISION
        #check for collision in x direction
        for grass_block in range(len(grass_collider_list)):
            grass_rect = grass_collider_list[grass_block]
            if grass_rect.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0
		    #check for collision in y direction
            if grass_rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
		    #check if colliding from below
                if self.vel_y < 0:
                    dy = -1
                    self.vel_y = 0
		    	#check if colliding from above
                elif self.vel_y >= 0:
                    dy = 0
                    self.vel_y = 0
        #check for lava collision
        for lava_block in range(len(lava_collider_list)):
            lava_rect = lava_collider_list[lava_block]
            if lava_rect.colliderect(self.rect):
                death = True
        #check for floor spike collision
        for floor_spike in range(len(floor_spike_collider_list)):
            floor_spike_rect = floor_spike_collider_list[floor_spike]
            if floor_spike_rect.colliderect(self.rect):
                death = True
        #check for roof spike collision
        for roof_spike in range(len(roof_spike_collider_list)):
            roof_spike_rect = roof_spike_collider_list[roof_spike]
            if roof_spike_rect.colliderect(self.rect):
                death = True
        #checking if collided with enemy rect if enemy is alive
        #check for collision in x direction by calling enemy character function
        if enemy_killed == False:
            if enemy_rect.colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                death = True
            #check for collision in y direction by calling enemy character function
            if enemy_rect.colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
		        #check if colliding from below
                    if self.vel_y < 0:
                        death = True
		    	    #check if colliding from aboved
                    elif self.vel_y >= 0:
                        self.vel_y = -13
                        self.jumped = True
                        self.killed_enemy = True
        #checking if player collides with exit
        if self.killed_enemy == True and exit_door_rect.colliderect(self.rect):
            game_complete = True
        else:
            game_complete = False

        #updating self.rect
        #update player coorditnates
        self.rect.x += dx
        self.rect.y += dy

        #adding boundries to bottom
        if self.rect.bottom > screen_height:
            self.rect.bottom = screen_height
            dy = 0
        #adding horizontal boundaries
        if self.rect.right > screen_width:
            self.rect.x = screen_width - self.width
        elif self.rect.left < 0:
            self.rect.x = 0

        #stopping people from jumping over and over part 2
        if dy == 0 and self.jumped == True:
            self.jumped = False
        else:
            self.jumped = True
        
        #character animations
        #changing player direction facing right and changing image right
        if self.right == True:
            img = pygame.image.load(walking_right[self.image_select])
            self.image = pygame.transform.scale(img, (30, 60))
            self.image_select += 1
        #changing player direction facing left and changing image left
        elif self.left == True: 
            img = pygame.image.load(walking_left[self.image_select])
            self.image = pygame.transform.scale(img, (30, 60))
            self.image_select += 1
        #if player doesn't move left or right it displays normal guy again
        else:
            img = pygame.image.load('guy.png')
            self.image = pygame.transform.scale(img, (30, 60))
        if self.image_select == 19:
            self.image_select = 0
        #checking if dead, if dead display character else return True which means player died
        tuple_var = (death, self.killed_enemy, game_complete)
        if death == False:
            screen.blit(self.image, self.rect)
        return tuple_var
    #dying animation 
    def dying_animation(self, number):
        dying_animation_list = ['dead_guy_1.png','dead_guy_2.png','dead_guy_3.png','dead_guy_4.png','dead_guy_5.png','dead_guy_6.png','dead_guy_7.png','dead_guy_8.png','dead_guy_9.png','dead_guy_10.png','dead_guy_11.png','dead_guy_12.png','dead_guy_13.png','dead_guy_14.png','dead_guy_15.png','dead_guy_16.png','dead_guy_17.png','dead_guy_18.png','dead_guy_19.png','dead_guy_20.png',]
        img = pygame.image.load(dying_animation_list[number])
        self.image = pygame.transform.scale(img, (30, 60))
        screen.blit(bg_img, (0, 0))
        screen.blit(exit_door_img, (exit_door_pos[0], exit_door_pos[1]))
        updating_world_data_displayed(for_loop_dirt_var, for_loop_grass_var, for_loop_lava_var, for_loop_floor_spike_var, for_loop_roof_spike_var)
        screen.blit(self.image, self.rect)
#adding Buttons
menu_button_rect = Rect(main_menu_pos[0] ,main_menu_pos[1] ,main_menu_image.get_width(), main_menu_image.get_height())
#function for mouse position
#function for menu button
def mouse_position_on_menu_button():
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    if mouse_rect.colliderect(menu_button_rect):
        return True
    else:
        return False
#while being offered to retry or quit, this is the quit option
quit_button_rect = Rect(quit_button_pos[0], quit_button_pos[1], quit_button_image.get_width(), quit_button_image.get_height(),)
#function for quit button
def mouse_position_on_quit_button():
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    if mouse_rect.colliderect(quit_button_rect):
        return True
    else:
        return False

retry_button_rect = Rect(retry_button_pos[0], retry_button_pos[1],retry_button_image.get_width(), retry_button_image.get_height(),)
#function for retry button
def mouse_position_on_rerty_button():
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    if mouse_rect.colliderect(retry_button_rect):
        return True
    else:
        return False
#rect's for mouse collision
resume_button_rect = (resume_button_img_pos[0], resume_button_img_pos[1], resume_button_img.get_width(), resume_button_img.get_height())
restart_button_rect = (restart_button_img_pos[0], restart_button_img_pos[1], restart_button_img.get_width(), restart_button_img.get_height())
help_button_rect = (help_button_img_pos[0], help_button_img_pos[1], help_button_img.get_width(), help_button_img.get_height())
leave_button_rect = (leave_button_img_pos[0], leave_button_img_pos[1], leave_button_img.get_width(), leave_button_img.get_height())
#main menu buttons / opition list
def main_menu_selected():
    #getting mouse pos and making it a rect
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    #screen blitting the main menu background
    screen.blit(main_menu_background_img, (main_menu_background_img_pos[0], main_menu_background_img_pos[1]))
    #checking if mouse is colliding with resume button
    if mouse_rect.colliderect(resume_button_rect):
        resume_button_return_var = True
    else:
        resume_button_return_var = False
    #checking if mouse is colliding with restart button
    if mouse_rect.colliderect(restart_button_rect):
        restart_button_return_var = True
    else:
        restart_button_return_var = False
    #checking if mouse is colliding with help button
    if mouse_rect.colliderect(help_button_rect):
        help_button_return_var = True
    else:
        help_button_return_var = False
    if mouse_rect.colliderect(leave_button_rect):
        leave_button_return_var = True
    else:
        leave_button_return_var = False
    return_tuple = (resume_button_return_var, restart_button_return_var, help_button_return_var, leave_button_return_var)
    return return_tuple


#help option buttons
def help_option_buttons():
    #grabbing the mouse position and making the mouse position into a rect
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    #checking if mouse rect is colliding with the next button rect
    if mouse_rect.colliderect(next_button_rect):
        next_button_collided = True
    else:
        next_button_collided = False
    #checking if mouse rect is colliding with the back button rect
    if mouse_rect.colliderect(back_button_rect):
        back_button_collided = True
    else:
        back_button_collided = False
    #making all the variables into a tuple and returning it
    tuple_var = (next_button_collided, back_button_collided)
    return tuple_var

#the function which recieves input for buttons
def help_option_reactive_buttons():
    #grabbing the key being pressed and checking whether its w/a/d
    key = pygame.key.get_pressed()
    if key[pygame.K_w] or key[pygame.K_UP]:
        #displaying w pressed if its pressed
        screen.blit(w_reactive_img_pressed, (350, 350))
    else:
        #displaying w if not pressed
        screen.blit(w_reactive_img, (350, 350))
    if key[pygame.K_a] or key[pygame.K_LEFT]:
        #displaying a pressed if its pressed
        screen.blit(a_reactive_img_pressed, (230, 350))
    else:
        #displaying a if not pressed
        screen.blit(a_reactive_img, (230, 350))
    if key[pygame.K_d] or key[pygame.K_RIGHT]:
        #displaying d pressed if its pressed
        screen.blit(d_reactive_img_pressed, (470, 350))
    else:
        #displaying d if not pressed
        screen.blit(d_reactive_img, (470, 350))

#drawing text function
def drawing_text(text, font, text_col, x, y):
    img = font.render(text, True , text_col)
    screen.blit(img, (x, y))
#leave button in game complete menu
def mouse_position_on_leave_button_2():
    mouse_pos = pygame.mouse.get_pos()
    mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
    if mouse_rect.colliderect(leave_button_img_2_rect):
        return True
    else:
        return False

#This function is used to keep the data saved perminantly (it makes the player )
def rewriting_DATA():
    #reading file and storing variables required for when rewritting the text file
    file = open('DATA.txt', 'r')
    incomplete_line = file.readline()
    complete_line = file.readline()
    level_1 = file.readline()
    level_2 = file.readline()
    level_3 = file.readline()
    file.close()
    #writting on the file
    file = open('DATA.txt', 'w')
    file.writelines(incomplete_line)
    file.writelines(complete_line)
    file.writelines(level_1)
    file.writelines(complete_line)
    file.writelines(level_3)
    file.close()

#fps clock
clock = pygame.time.Clock()
#player spawning
player = Player(400, 320)
#enemy spawning
enemy_character = enemy(200, 450)
#variable for checking if enemy was killed
killed_enemy = False
#variable for going through every death animation
death_animation_var = 0
#variable for loop
run = True
starting_time = time.time()
while run:
    clock.tick(25)
    if death == False and game_paused == False and game_complete == False:
        #to display background
        screen.blit(bg_img, (0, 0))
        screen.blit(exit_door_img, (exit_door_pos[0], exit_door_pos[1]))
        #display blocks
        updating_world_data_displayed(for_loop_dirt_var, for_loop_grass_var, for_loop_lava_var, for_loop_floor_spike_var, for_loop_roof_spike_var)
        #update enemy
        if killed_enemy == False:
            enemy_rect_and_image = enemy_character.update()
        #update player
        tuple_var_for_player = player.update(enemy_rect_and_image[0], killed_enemy)
        if tuple_var_for_player[0] == True:
            death = True
        #checking if player kills enemy
        if tuple_var_for_player[1] == True:
            killed_enemy = True
            if death_animation_var < len(enemy_dying_list):
                enemy_character.enemy_dying_animation(death_animation_var)
                death_animation_var += 1
        if tuple_var_for_player[2] == True:
            death = False 
            game_paused = False
            game_complete = True
        #events
        for event in pygame.event.get():
            #if human closes window
            if event.type == pygame.QUIT:
                pygame.quit()
            #checks if a mouse is hovered
            #updating mouse
        if mouse_position_on_menu_button() == True:
            screen.blit(main_menu_image_hovered, (main_menu_pos[0], main_menu_pos[1]))
            #if the mouse is clicked on the game is terminated
            if event.type == pygame.MOUSEBUTTONDOWN:
                game_paused = True
        else:
            #display button if not beidng hovered
            screen.blit(main_menu_image, (main_menu_pos[0], main_menu_pos[1]))
        end_time = str(int(time.time() - starting_time))
    #if dead then:
    elif offer_retry == False and game_paused == False and game_complete == False:
        #run function to play full death animation
        player.dying_animation(num)
        if killed_enemy == False:
            screen.blit(enemy_rect_and_image[1], enemy_rect_and_image[0])
        num += 1
        if num == 20:
            offer_retry = True
    #offering retry
    if offer_retry == True and game_paused == False and game_complete == False:
        for event in pygame.event.get():
            #if human closes window
            if event.type == pygame.QUIT:
                pygame.quit()
        #bliting the background
        screen.blit(bg_img, (0, 0))
        #function for mouse on quit button
        if mouse_position_on_quit_button() == True:
            screen.blit(quit_button_image_hovered, (quit_button_pos[0], quit_button_pos[1]))
            if event.type == pygame.MOUSEBUTTONDOWN:
                run = False
        else:
            screen.blit(quit_button_image, (quit_button_pos[0], quit_button_pos[1]))
        #function for mouse on retry button
        if mouse_position_on_rerty_button() == True:
            screen.blit(retry_button_image_hovered, (retry_button_pos[0], retry_button_pos[1]))
            if event.type == pygame.MOUSEBUTTONDOWN:
                #reseting game
                player = Player(400, 320)
                enemy_character = enemy(200, 450)
                offer_retry = False
                death = False
                num = 0
                killed_enemy = False
                death_animation_var = 0
                starting_time = time.time()
        else:
            screen.blit(retry_button_image, (retry_button_pos[0], retry_button_pos[1]))

    #displaying the game paused menu if game is paused
    elif offer_retry == False and game_paused == True and game_complete == False and help_option_selected == False:
        #running the function to check whether buttons are being hovered and returning a tuple for each button whether they are ot aren't
        main_menu_return_tuple = main_menu_selected()
        #checking if resume button is being hovered
        if main_menu_return_tuple[0] == True:
            #bliting resume button if hovered
            screen.blit(resume_button_hovered_img,(resume_button_img_pos[0], resume_button_img_pos[1]))
            #resuming game if button is pressed
            if event.type == pygame.MOUSEBUTTONDOWN:
                game_paused = False
        elif main_menu_return_tuple[0] == False:
            #bliting resume button
            screen.blit(resume_button_img,(resume_button_img_pos[0], resume_button_img_pos[1]))
        #checking if restart button is being hovered
        if main_menu_return_tuple[1] == True:
            screen.blit(restart_button_hovered_img, (restart_button_img_pos[0], restart_button_img_pos[1]))
            #restarting game if restart button is clicked
            if event.type == pygame.MOUSEBUTTONDOWN:
                #reseting game
                player = Player(400, 320)
                enemy_character = enemy(200, 450)
                offer_retry = False
                death = False
                num = 0
                killed_enemy = False
                death_animation_var = 0
                game_paused = False
                starting_time = time.time()
        #elif if restart button isn't hovered
        elif main_menu_return_tuple[1] == False:
            screen.blit(restart_button_img, (restart_button_img_pos[0], restart_button_img_pos[1]))
        #checking if help button is being hovered and blitting either the normal img or the hovered version
        if main_menu_return_tuple[2] == True:
            screen.blit(help_button_hovered_img, (help_button_img_pos[0], help_button_img_pos[1]))
            if event.type == pygame.MOUSEBUTTONDOWN:
                help_option_selected = True
        elif main_menu_return_tuple[2] == False:
            screen.blit(help_button_img, (help_button_img_pos[0], help_button_img_pos[1]))
        #checking if leave button is being hovered and blitting either the normal img or the hovered version
        if main_menu_return_tuple[3] == True:
            screen.blit(leave_button_hovered_img , (leave_button_img_pos[0], leave_button_img_pos[1]))
            #if leave button is pressed then exit the code
            if event.type == pygame.MOUSEBUTTONDOWN:
                run = False
        elif main_menu_return_tuple[3] == False:
            screen.blit(leave_button_img , (leave_button_img_pos[0], leave_button_img_pos[1]))
        #ensuring that if player quits the game ends
        for event in pygame.event.get():
            #if human closes window
            if event.type == pygame.QUIT:
                pygame.quit()
    #if player presses help button in option menu
    elif offer_retry == False and game_paused == True and game_complete == False and help_option_selected == True:
        if help_option_next_page_selected == False:
            #getting mouse pos and making it a rect
            mouse_pos = pygame.mouse.get_pos()
            mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
            #screen blitting the main menu background
            screen.blit(main_menu_background_img, (main_menu_background_img_pos[0], main_menu_background_img_pos[1]))
            #screen bliting all the help option images
            #dirt img
            screen.blit(help_option_dirt_img, (230, 135))
            #grass img
            screen.blit(help_option_grass_img, (230, 190))
            #lava img
            screen.blit(help_option_lava_img, (230, 245))
            #floor spike img
            screen.blit(help_option_floor_spike_img, (230, 300))
            #roof spike img
            screen.blit(help_option_roof_spike_img, (230, 355))
            #exit door img
            screen.blit(help_option_exit_door_img, ((230, 400)))
            #describing what each thing is, in help option menu
            #dirt description
            drawing_text('dirt is a platform you can walk on.', help_option_text_font, (255,255,255), 280, 145)
            #grass description
            drawing_text('grass is a platform you can walk on.', help_option_text_font, (255,255,255), 280, 200)
            #lava description
            drawing_text('lava is an object that kills you.', help_option_text_font, (255,255,255), 280, 255)
            #floor spike description
            drawing_text('floor spike is an object that kills you.', help_option_text_font, (255,255,255), 280, 305)
            #roof spike description
            drawing_text('roof spike is an object that kills you.', help_option_text_font, (255,255,255), 280, 360)
            #exit door img description
            drawing_text('The exit door can only be used by killing', help_option_text_font, (255,255,255), 280, 410)
            drawing_text('the enemy and standing infront of it.', help_option_text_font, (255,255,255), 280, 425)

            #tuple which contains booleon variables for whether the buttons are colliding or not
            tuple_help_buttons_var = help_option_buttons()
            if tuple_help_buttons_var[0] == True:
                #displaying the next button img hovered if its colliding
                screen.blit(next_button_hovered_img, (next_button_img_pos[0],next_button_img_pos[1]))
                if event.type == pygame.MOUSEBUTTONDOWN:
                    time.sleep(0.2)
                    help_option_next_page_selected = True
            else:
                #displaying the next button img if not colliding
                screen.blit(next_button_img, (next_button_img_pos[0],next_button_img_pos[1]))
            if tuple_help_buttons_var[1] == True:
                #displaying the back button img hovered if its colliding
                screen.blit(back_button_img_hovered, (back_button_img_pos[0], back_button_img_pos[1]))
                if event.type == pygame.MOUSEBUTTONDOWN:
                    time.sleep(0.2)
                    help_option_selected = False
            else:
                #displaying the back button img if not colliding
                screen.blit(back_button_img, (back_button_img_pos[0], back_button_img_pos[1]))
        #if the player presses the next page button
        elif help_option_next_page_selected == True:
            mouse_pos = pygame.mouse.get_pos()
            mouse_rect = Rect(mouse_pos[0], mouse_pos[1], 1, 1)
            #screen blitting the main menu background
            screen.blit(main_menu_background_img, (main_menu_background_img_pos[0], main_menu_background_img_pos[1]))
            #blitting a mini enemy image
            screen.blit(mini_enemy_img, (mini_enemy_img_pos[0], mini_enemy_img_pos[1]))
            #blitting a mini guy character
            screen.blit(mini_guy_img, (mini_guy_img_pos[0], mini_guy_img_pos[1]))
            #displaying text on page 2
            #describing enemy
            drawing_text('The enemy in the level looks like this and', help_option_text_font, (255,255,255), 280, 145)
            drawing_text('can only be killed by jumping on his head.', help_option_text_font, (255,255,255), 280, 160)
            #describing the players character
            drawing_text('This is your character.', help_option_text_font, (255,255,255), 280, 235)
            drawing_text('Use W, A and D to control your character.', help_option_text_font, (255,255,255), 280, 290)
            drawing_text('press W/A/D to see your key presses are working', help_option_text_font, (255,255,255), 240, 315)
            #advanced jump mechanic explination
            drawing_text('To jump higher you will need to use advanced', help_option_text_font, (139,0,139), 230, 500)
            drawing_text('jump mechanic: ', help_option_text_font, (139,0,139), 230, 515)
            drawing_text('HOLD the "W" key for multiple', help_option_text_font, (255,255,255), 340, 515)
            drawing_text('jumps (2 or 3) before attempting to make the parkour', help_option_text_font, (255,255,255), 230, 530)
            drawing_text('in order to jump higher.', help_option_text_font, (255,255,255), 230, 545)
            #the reactive buttons which work if the corisponding key is pressed
            help_option_reactive_buttons()
            #function which returns a true or false variable which checks whether the button is being hovered or not.
            back_var = help_option_buttons()[1]
            if back_var == True:
                screen.blit(back_button_img_hovered, (back_button_img_pos[0], back_button_img_pos[1]))
                if event.type == pygame.MOUSEBUTTONDOWN:
                    time.sleep(0.2)
                    help_option_next_page_selected = False
            else:
                screen.blit(back_button_img, (back_button_img_pos[0], back_button_img_pos[1]))
        #checking whether human closes the window
        for event in pygame.event.get():
            #if human closes window
            if event.type == pygame.QUIT:
                pygame.quit()
    #if player completes game
    if game_complete == True:
        #changing the data for all levels by editing the text file and reading it across multiple python files which allows for permanant saved data, 
        rewriting_DATA()
        #blitting the background img
        screen.blit(game_complete_background_img, (game_complete_background_pos[0], game_complete_background_pos[1]))
        time_string = (f' you took {end_time} secconds to complete this level!')
        drawing_text(time_string, text_font, (139,0,139), 120, 300)
        if int(end_time) < 20:
            drawing_text('YOUR QUICK', text_font, (139,0,139), 300, 340)
        elif int(end_time) > 20 and int(end_time) < 40:
            drawing_text('average speed', text_font, (139,0,139), 300, 340)
        else:
            drawing_text('slow poke', text_font, (139,0,139), 330, 340)
        #making a button and checking whether player is hovering over it or not.
        if mouse_position_on_leave_button_2() == True:
            screen.blit(leave_button_hovered_img_2, (leave_button_img_2_pos[0], leave_button_img_2_pos[1]))
            #checking whether the player clicks quit
            if event.type == pygame.MOUSEBUTTONDOWN:
                run = False
        else:
            screen.blit(leave_button_img_2, (leave_button_img_2_pos[0], leave_button_img_2_pos[1]))
        #checking if player closes the game
        for event in pygame.event.get():
            #if human closes window
            if event.type == pygame.QUIT:
                pygame.quit()
    #most important function for all graphics
    pygame.display.update()